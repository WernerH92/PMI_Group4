"""Entry script to run the Assignment 3 comparisons and view the results from SphericalMeasurement"""

import argparse
import math
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nifti", type=Path, help="NIfTI volume to measure and display.")
    parser.add_argument("--center", type=int, nargs=3, default=(381, 300, 60),
                        metavar=("X", "Y", "Z"), help="Measurement centre in voxel indices.")
    parser.add_argument("--radius", type=float, default=20.0,
                        help="Sphere radius in mm (default: 20).")
    args = parser.parse_args()

    # Reject bad console arguments before starting tests.
    if args.nifti is not None and not args.nifti.is_file():
        parser.error(f"NIfTI file not found: {args.nifti}")
    if not math.isfinite(args.radius) or args.radius <= 0:
        parser.error("--radius must be positive and finite")

    # This import ordering ensures that the --help command also works before the package is installed.
    from pmi_lib.test import test_filters, test_spheres, test_parallel, test_measurement

    print("\n1. Bilateral filter: Python vs C (expect mean squared difference near zero).", flush=True)
    test_filters()
    print("\n2. Sphere generation: Python vs NumPy vs C (expect zero differences).", flush=True)
    test_spheres()
    print("\n3. Slice filtering: sequential vs multithreaded runtimes in seconds "
          "(expect zero mean differences).", flush=True)
    test_parallel()

    if args.nifti is not None:
        # The viewer waits for its window to close, so we do it last here
        print("\n4. Spherical measurement: mean, standard deviation and maximum inside the sphere.\n"
              f"Input: {args.nifti}\n"
              f"Centre (x, y, z): {tuple(args.center)} voxels | radius: {args.radius:g} mm.\n"
              "The viewer shows the cropped sphere overlay result.", flush=True)
        test_measurement(str(args.nifti), *args.center, radius=args.radius)


if __name__ == "__main__":
    main()
