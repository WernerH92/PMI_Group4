# PMI Group 4 — Assignment 3A/3B

# Made by: Ali Ali, Werner Huiskes, Teun Hofstra, Niels Kersten

This zip package contains sphere generators written in Python / NumPy / C for
comparison, optimized bilateral filters using multithreading and the option
to do basic statistical spherical measurements on NIfTI images using spheres.
Image arrays and image spacing use `(y, x)` or `(z, y, x)` convention, 
radii and spatial filter sigma's use milimeters.

Python 3.12+ is needed to run this library. Run the following commands
inside this folder: dependencies and compilation of the C scripts should
be done automatically.

Windows PowerShell: install MinGW-w64/GCC and add its `bin` folder to `PATH`.

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install .
.\.venv\Scripts\python.exe run_assignment.py
```

Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install .
.venv/bin/python run_assignment.py
```

macOS:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install .
.venv/bin/python run_assignment.py
```

The runner script will print out filter/sphere comparisons and runtimes.
Expected mean squared differences should be near zero for the Python/C filter
comparisons and exactly zero for the other comparisons. 

To run these same checks and also open a spherical measurement overlay, supply 
a 3D NIfTI file and a sphere that fits inside it. As an example:

```bash
.venv/bin/python run_assignment.py --nifti "/path/to/ct_jaw.nii.gz" --center 381 300 60 --radius 20
```
`--center X Y Z` and `--radius MM` are optional arguments. They default to voxel 
coordinates `(381, 300, 60)` and a radius of `20 mm`, matching the example in
the assignment.

On Windows use `.\.venv\Scripts\python.exe` instead. The command `--help` lists options.
Leaving out `--nifti` runs only the comparisons. 